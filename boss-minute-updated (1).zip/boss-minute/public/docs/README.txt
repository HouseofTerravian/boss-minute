Drop your four PDFs here with the exact filenames listed in the main README.
